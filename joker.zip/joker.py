import wordlist
import os
from termcolor import colored
import pyfiglet
result = pyfiglet.figlet_format("JOKER",font='isometric3')
print(colored(result,'green'))
print(colored("                    USE FOR EDUCATIONAL PURPOSE ONLY  ",'red',attrs=['bold']))
print(colored("     Author : Technical B9T  ",'yellow',attrs=['bold']))
print(colored("     YouTube:Technical B9T",'yellow',attrs=['bold']))

print("************************************************************** ")

print(colored("        1)Create wordlist",'green',attrs=['bold']))
print(colored("        0)Exit ",'green',attrs=['bold']))
a = int(input(colored("select option : ",'magenta',attrs=['bold'])))

if a ==1:
 def password():
   generator = wordlist.Generator(input(colored("1.Enter a Suggested Password : ",'magenta',attrs=['bold'])))
   min = int(input(colored("2.Enter min digit : ",'magenta',attrs=['bold'])))
   max = int(input(colored("3.Enter max digit : ",'magenta',attrs=['bold'])))
   outfile = open('password.txt','w')
   for each in generator.generate(min ,max):
    p = each
    outfile.write(p+'\n')
   outfile.close()
   print(colored("Passwordlist has been created successfully",'green'))
   os.system("chmod +x password.txt")
   os.system("ls")
 password()
else:
  quit()
